import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


/**
 * Project 5 - Customer
 * This class extends the user class giving it the permissions that come with being a Customer.
 *
 */

public class Customer extends User {

    //basic constructors
    public Customer(String username, String email, String password) {
        super(username, email, password);
    }

    public Customer(String username, String email, String password, ArrayList<String> blockedUsernames) {
        super(username, email, password, blockedUsernames);
    }

    private JFrame stats;
    
    //reads data from a CSV file named stores.csv, extracts store-related information, and computes statistics like the total messages received and messages from the user for each store. 
    // It then sorts these stores alphabetically or in reverse alphabetical order based on the input parameter and returns a formatted string containing these statistics.
    public String viewStatistics(boolean alphabetical) throws IOException {
    // Initialize file reader for 'stores.csv'
    FileReader fr = null;
    try {
        fr = new FileReader("stores.csv");
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }

    // Initialize buffered reader
    BufferedReader br = null;
    if (fr != null) {
        br = new BufferedReader(fr);
    }

    // Initialize ArrayLists to store messages, stores, and statistics
    ArrayList<String> messages = new ArrayList<>();
    ArrayList<String> stores = new ArrayList<>();
    ArrayList<Integer> totalMessagesReceived = new ArrayList<>();
    ArrayList<Integer> messagesFromUser = new ArrayList<>();

    // Reading data from the file and populating the ArrayLists
    String line;
    String store;
    line = br.readLine();
    while (line != null) {
        store = line.substring(1, line.indexOf(',') - 1);
        messages.add(line.substring(1, line.length() - 1));
        if (!stores.contains(store)) {
            stores.add(store);
        }
        line = br.readLine();
    }

    // Calculating total messages received for each store
    for (int i = 0; i < messages.size(); i++) {
        line = messages.get(i);
        store = line.substring(0, line.indexOf(",") - 1);
        line = line.substring(line.indexOf(",") + 1);
        int messagesReceived = Integer.parseInt(line.substring(1, line.indexOf(",") - 1));
        totalMessagesReceived.add(messagesReceived);
    }

    // Calculating messages from user for each store
    for (int i = 0; i < stores.size(); i++) {
        int counter = 0;
        for (int j = 0; j < messages.size(); j++) {
            line = messages.get(j);
            String user = line.substring(line.indexOf(',', line.indexOf(',')));
            store = line.substring(0, line.indexOf(','));
            if (user.equals(this.getUsername()) && store.equals(stores.get(i))) {
                counter++;
            }
        }
        messagesFromUser.add(counter);
    }

    // Creating HashMaps to map store names to statistics
    HashMap<String, Integer> listOne = new HashMap<>();
    for (int i = 0; i < stores.size(); i++) {
        listOne.put(stores.get(i), totalMessagesReceived.get(i));
    }
    HashMap<String, Integer> listTwo = new HashMap<>();
    for (int i = 0; i < stores.size(); i++) {
        listTwo.put(stores.get(i), messagesFromUser.get(i));
    }

    // Sorting and building the result string
    Collections.sort(stores);
    StringBuilder sortMessages = new StringBuilder();
    if (alphabetical) {
        // Sort alphabetically
        for (int i = 0; i < stores.size(); i++) {
            sortMessages.append("Store: " + stores.get(i) + " - Number of messages received: " + listOne.get(stores.get(i)) + "\\n");
        }
    } else {
        // Sort in reverse alphabetical order
        for (int i = stores.size() - 1; i >= 0; i--) {
            sortMessages.append("Store: " + stores.get(i) + " - Number of messages received: " + listOne.get(stores.get(i)) + "\\n");
        }
    }

    stats = new JFrame();

    JOptionPane.showMessageDialog(stats, sortMessages.toString());
        
    return sortMessages.toString();
}

    //formats the user's information, including username, email, password, and a list of blocked users into a string format. 
    public String toString() {
        String blockedList = "";
        if (getBlockedUsers().size() > 0) {
            for (User user : getBlockedUsers()) {
                blockedList += user.getUsername() + ",";
            }
            blockedList = blockedList.substring(0, blockedList.length() - 1);
        }
        String ans = String.format("\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"", getUsername(), getEmail(),
                getPassword(), "b", blockedList);
        return ans;
    }

}
