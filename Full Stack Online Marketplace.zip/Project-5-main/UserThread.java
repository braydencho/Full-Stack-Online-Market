import java.io.*;
import java.net.Socket;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;

public class UserThread implements Runnable {
    private Socket client;
    private BufferedReader reader;
    private PrintWriter writer;
    private ObjectOutputStream oos;
    private ObjectInputStream ois;
    private List<User> users;
    private ArrayList<User> blockedUsers = new ArrayList<>();
    private final static String loginFilePath = "login.csv";
    private final static String userFilePath = "users.csv";
    private final static String storeFilePath = "stores.csv";

    public UserThread(Socket client) {
        try {
            this.client = client;
            reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
            writer = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
            oos = new ObjectOutputStream(client.getOutputStream());
            ois = new ObjectInputStream(client.getInputStream());
            this.users = new ArrayList<>();
            loadUsers();
            loadUserObjects();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readCommand() {
        try {
            int command = Integer.parseInt(reader.readLine());
            switch (command) {
                case 1:
                    authenticateUser();
                    break;
                case 2:
                    registerUser();
                    break;
                case 3:
                    loadBlocked();
                    break;
                case 4:
                    loadUnblocked();
                    break;
                case 5:
                    addBlocked();
                    break;
                case 6:
                    getAllStores();
                default:
            }
        } catch (IOException e) {
            closeStreams();
        }
    }

    public void loadUsers() throws IOException {
        users = new ArrayList<>();
        File file = new File(loginFilePath);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 4) continue;
                String username = parts[0].trim();
                String email = parts[1].trim();
                String password = parts[2].trim();
                String type = parts[3].trim();

                User user;
                if (type.equalsIgnoreCase("customer")) {
                    user = new Customer(username, email, password);
                } else if (type.equalsIgnoreCase("seller")) {
                    user = new Seller(username, email, password);
                } else {
                    continue;
                }
            }
        }
    }

    public synchronized void loadUserObjects() throws IOException {
        users = new ArrayList<>();
        if (new BufferedReader(new FileReader(userFilePath)).readLine() != null) {
            ObjectInputStream readUsers = new ObjectInputStream(new FileInputStream(userFilePath));
            try {
                Object object = readUsers.readObject();
                while (readUsers.available() > 0) {
                    User user = (User) object;
                    users.add(user);
                    readUsers.readLine();
                    object = readUsers.readObject();

                }
            } catch (IOException e) {
                readUsers.close();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public synchronized void saveUsers() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(loginFilePath)); ObjectOutputStream userWriter
                = new ObjectOutputStream(new FileOutputStream(userFilePath))) {
            for (User user : users) {
                writer.println(user.toString());
                userWriter.writeObject(user);
                userWriter.write('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void registerUser() throws IOException {
        String[] info = reader.readLine().split(",");
        String username = info[0];
        String email = info[1];
        String password = info[2];
        String userType = info[3];

        if (isUsernameTaken(username)) {
            writer.write("false");
            writer.println();
            writer.flush();
            return;
        }

        User newUser = null;
        if ("customer".equalsIgnoreCase(userType)) {
            newUser = new Customer(username, email, password);
            newUser.setBlockedUsers(blockedUsers);
        } else if ("seller".equalsIgnoreCase(userType)) {
            newUser = new Seller(username, email, password);
            newUser.setBlockedUsers(blockedUsers);
        } else {
            writer.write("false");
            writer.println();
            writer.flush();
            return;
        }

        users.add(newUser);
        saveUsers();
        writer.write("true");
        writer.println();
        writer.flush();
    }

    // Check if a username is already taken
    public boolean isUsernameTaken(String username) {
        return users.stream().anyMatch(user -> user.getUsername().equalsIgnoreCase(username));
    }

    public void authenticateUser() throws IOException {
        loadUserObjects();
        String[] info = reader.readLine().split(",");
        String username = info[0];
        String password = info[1];
        oos.writeObject(users.stream()
                .filter(user -> user.getUsername().equalsIgnoreCase(username) && user.getPassword().equals(password))
                .findFirst()
                .orElse(null));
    }

    public synchronized void loadBlocked() throws IOException {
        loadUserObjects();
        try {
            String username = reader.readLine();
            for (User user : users) {
                if (user.getUsername().equals(username)) {
                    blockedUsers = user.getBlockedUsers();
                    oos.writeObject(blockedUsers);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void loadUnblocked() throws IOException {
        ArrayList<User> unblockedUsers = new ArrayList<>();
        String username = reader.readLine();
        try {
            for (User user : users) {
                if (!blockedUsers.contains(user) && !username.equals(user.getUsername())) {
                    unblockedUsers.add(user);
                }
            }
            oos.writeObject(unblockedUsers);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void addBlocked() {
        try {
            User currentUser = null;
            String[] info = reader.readLine().split(",");
            String username = info[0];
            String blockedUser = info[1];
            for (User user : users) {
                if (user.getUsername().equals(username)) {
                    currentUser = user;
                    blockedUsers = user.getBlockedUsers();
                }
            }
            assert currentUser != null;
            currentUser.blockUser(blockedUser, (ArrayList<User>) users);
            saveUsers();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void getAllStores() {
        ArrayList<Store> temp = new ArrayList<>();
        ArrayList<Store> fullList = new ArrayList<>();
        try {
            loadUserObjects();
            for (User user : users) {
                if (user instanceof Seller) {
                    temp = ((Seller) user).getStores();
                    fullList.addAll(temp);
                }
            }
            oos.writeObject(fullList);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (!client.isClosed()) {
            readCommand();
        }
        closeStreams();
    }

    public void closeStreams() {
        try {
            reader.close();
            writer.close();
            oos.close();
            ois.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
