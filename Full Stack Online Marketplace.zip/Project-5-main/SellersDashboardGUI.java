import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SellersDashboardGUI extends JFrame {
    private Menu client;
    private Seller currentSeller;
    private JButton manageAccountsButton;
    private JButton viewMessagesButton;

    public SellersDashboardGUI() {
        this.client = client;
        this.currentSeller = currentSeller;
        setTitle("Seller's Dashboard");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        manageAccountsButton = new JButton("Manage Accounts");
        manageAccountsButton.addActionListener(this::onManageAccountsClicked);

        viewMessagesButton = new JButton("View Messages");
        viewMessagesButton.addActionListener(this::onViewMessagesClicked);

        add(manageAccountsButton);
        add(viewMessagesButton);
    }

    private void onManageAccountsClicked(ActionEvent event) {
        SellersManageAccountsGUI manageAccountsGUI = new SellersManageAccountsGUI(currentSeller);
        JFrame frame = new JFrame("Manage Accounts");
        frame.setContentPane(manageAccountsGUI);
        frame.setSize(600, 400); // Set appropriate size
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }



    private List<Message> readMessagesFromCSV(String csvFilePath) {
        List<Message> messages = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                int id = Integer.parseInt(data[0].substring(1, data[0].length() - 1));
                String time = data[1];
                String sender = data[2];
                String receiver = data[3];
                String messageContent = data[4];
                boolean delBySender = Boolean.parseBoolean(data[5]);
                boolean delByReceiver = Boolean.parseBoolean(data[6]);

                Message message = new Message(id, time, sender, receiver, messageContent, delBySender, delByReceiver);
                messages.add(message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return messages;
    }

    private void onViewMessagesClicked(ActionEvent event) {
        String csvFilePath = "path_to/messages.csv"; // Correct this path as per your file system
        List<Message> messages = readMessagesFromCSV(csvFilePath);
        new SellersMessageGUI(currentSeller, messages).setVisible(true); // Ensure SellersMessageGUI is implemented correctly
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SellersDashboardGUI().setVisible(true);
        });
    }
}
