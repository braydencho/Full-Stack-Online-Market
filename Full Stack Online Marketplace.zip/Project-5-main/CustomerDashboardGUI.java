import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Project 5 - CustomerDashboardGUI
 * This class creates a GUI of the customer dashboard, in which the customer can communicate their desired
 * commands to the server via buttons and text fields.
 *
 * @author Jessica He,
 */

public class CustomerDashboardGUI extends JComponent implements Runnable {
    private Menu client;
    private Customer currentUser;
    private JFrame dashboard = new JFrame("Customer Dashboard");
    private JButton profile;
    private JButton manage;
    private JButton addBlockedUser;
    private JButton profileBack;
    private JButton blockBack;
    private JComboBox<String> pickUnblocked;

    public CustomerDashboardGUI(Menu client, Customer currentUser) {
        this.client = client;
        this.currentUser = currentUser;
        initializeDashboard();
    }
    private void initializeDashboard() {
        dashboard = new JFrame("Customer Dashboard");
        dashboard.setSize(900, 600);
        dashboard.setLocationRelativeTo(null);
        dashboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    ActionListener actionListener = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == profile) {
                dashboard.setVisible(false);
                refreshPage();
                profilePage();
            }
            if (e.getSource() == manage) {
                refreshPage();
                try {
                    bUsersPage();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                } catch (ClassNotFoundException ex) {
                    throw new RuntimeException(ex);
                }
            }
            if (e.getSource() == addBlockedUser) {
                String blockedUser = (String) pickUnblocked.getSelectedItem();
                client.blockUser(currentUser.getUsername(), blockedUser);
                refreshPage();
                try {
                    bUsersPage();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                } catch (ClassNotFoundException ex) {
                    throw new RuntimeException(ex);
                }
            }
            if (e.getSource() == profileBack) {
                refreshPage();
                try {
                    startDashboard();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                } catch (ClassNotFoundException ex) {
                    throw new RuntimeException(ex);
                }
            }
            if (e.getSource() == blockBack) {
                refreshPage();
                profilePage();
            }
        }
    };


    @Override
    public void run() {
        try {
            startDashboard();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void startDashboard() throws IOException, ClassNotFoundException {
        refreshPage();
        ArrayList<Store> stores = client.getAllStores();
        JPanel startPanel = new JPanel(new GridBagLayout());
        JPanel storePanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        profile = new JButton(currentUser.getUsername() + "'s Profile");
        profile.addActionListener(actionListener);

        storePanel.setPreferredSize(new Dimension(600, 400));
        int count = 0;
        for (Store store : stores) {
            count++;
            JButton storeButton = new JButton(store.getStoreName());
            gbc.gridx = 1;
            gbc.gridy = count;
            gbc.anchor = GridBagConstraints.NORTH;
            storeButton.setPreferredSize(new Dimension(600, 100));
            storePanel.add(storeButton, gbc);
        }
        JScrollPane storeScrollPane = new JScrollPane(storePanel);
        configureScrollPane(gbc, storeScrollPane, startPanel);

        dashboard.getContentPane().add(startPanel);
        dashboard.setVisible(true);
    }

    private void configureScrollPane(GridBagConstraints gbc, JScrollPane storeScrollPane, JPanel startPanel) {
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.insets = new Insets(100, 50, 0, 0);
        storeScrollPane.setPreferredSize(new Dimension(600, 400));
        storeScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        storeScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        startPanel.add(storeScrollPane, gbc);
        gbc.anchor = GridBagConstraints.FIRST_LINE_END;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.ipadx = 40;
        gbc.ipady = 20;
        gbc.insets = new Insets(0, 0, 0, 0);
        profile.setOpaque(false);
        profile.setContentAreaFilled(false);
        profile.setBorderPainted(false);
        startPanel.add(profile, gbc);
    }

    public void profilePage() {
        Container container = dashboard.getContentPane();
        JPanel profilePanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        JLabel name = new JLabel("<html>Welcome " + currentUser.getUsername() + ",<BR>Your Account<html>");
        manage = new JButton("Manage Blocked Users");
        manage.addActionListener(actionListener);
        profileBack = new JButton("Back");
        profileBack.addActionListener(actionListener);

        container.add(profilePanel);
        name.setFont(new Font("Roboto", Font.PLAIN, 30));
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.insets = new Insets(0,15,50,0);
        profilePanel.add(name,gbc);
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.insets = new Insets(0,0,0,10);
        profilePanel.add(manage, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.insets = new Insets(-175,0,0,0);
        gbc.anchor = GridBagConstraints.LINE_START;
        profileBack.setContentAreaFilled(false);
        profileBack.setOpaque(false);
        profileBack.setBorderPainted(false);
        profilePanel.add(profileBack, gbc);

        dashboard.setSize(500, 400);
        dashboard.setLocationRelativeTo(null);
        dashboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dashboard.setVisible(true);
    }

    public void bUsersPage() throws IOException, ClassNotFoundException {
        String bUsers = "Blocked Users: \n";
        ArrayList<User> blocked = client.getBlocked(currentUser.getUsername());
        ArrayList<User> unblocked = client.getUnblocked(currentUser.getUsername());
        String[] unblockedUsers = new String[unblocked.size()];

        if (blocked.isEmpty()){
            bUsers = "No Users Have Been Blocked";
        } else {
            for (User user : blocked) {
                bUsers += user.getUsername() + "\n";
            }
        }

        for (int i = 0; i < unblocked.size(); i++) {
            unblockedUsers[i] = unblocked.get(i).getUsername();
        }

        Container container = dashboard.getContentPane();
        JPanel blockedPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        JTextArea blockedUsers = new JTextArea(bUsers);
        JScrollPane blockedView = new JScrollPane(blockedUsers);
        pickUnblocked = new JComboBox<>(unblockedUsers);
        addBlockedUser = new JButton("Add");
        addBlockedUser.addActionListener(actionListener);
        blockBack = new JButton("Back");
        blockBack.addActionListener(actionListener);

        container.add(blockedPanel);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;
        blockedUsers.setEditable(false);
        blockedView.setPreferredSize(new Dimension(300, 200));
        blockedView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        blockedPanel.add(blockedView,gbc);
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;
        pickUnblocked.setPreferredSize(new Dimension(100, 25));
        gbc.insets = new Insets(0,0,50,10);
        blockedPanel.add(pickUnblocked, gbc);
        gbc.insets = new Insets(50,0,0,10);
        blockedPanel.add(addBlockedUser, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.insets = new Insets(-300,0,0,10);
        blockBack.setBorderPainted(false);
        blockBack.setOpaque(false);
        blockBack.setContentAreaFilled(false);
        blockedPanel.add(blockBack, gbc);

        dashboard.setSize(500, 400);
        dashboard.setLocationRelativeTo(null);
        dashboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dashboard.setVisible(true);
    }

    public void refreshPage() {
        dashboard.getContentPane().removeAll();
        dashboard.repaint();
    }
}


