# CS180-Project5 L29-4-Team 135
Option 2

**//How to Compile and Run the Code**
1. Run Server.java
2. Eun MarketplaceApplicationGUI.java

**//Submissions**
 - Aiden submitted the program to Vocareum.
 - Joshua submitted the report
 - Brayden submitted the presentation to Brightspace.

**//The Functionality of Each Class**

**Server:**
  This class represents the server that all the clients connect to. Besides the start and close methods, this class has a method that creates a new thread for every new client connected.

**UserThread**
  This class creates the client threads that connect each client to the server. It also houses many of the methods that receive information from the Client class(Menu.java), read and write to files, and write the requested command results back to the client. 

**Menu**
    This class is out client class. The methods of this class get called based on user interaction with the GUI. This class is connected to the server through socket, and writes and receives user input and desired outputs.

**MarketplaceApplicationGUI:**
    This class houses the starting GUI where the user logs in and signs up. This class also contains methods that call methods from Menu(Client).java which will send commands and information regarding account registration and verification that it would like the server to execute.

**CustomerDashboardGUI:**
    When a customer is authenticated in MarketplaceApplicationGUI.java, this GUI gets called. In this GUI, customers can use the navigation buttons to see a list of stores and their profile. Within their profile, they also have the ability to block users. Similarly to MarketplaceApplicationGUI, this class calls methods from Menu in order to speak and request information from the server.

**SellerDashboardGUI:**
    When a seller is authenticated in MarketplaceApplicationGUI.java, this GUI gets called. Within this GUI, sellers are given the option via JButton to create stores, view and send messages, as well as managing blocked users.

**SellersManageAccountGUI**
    When a seller presses the manage account GUI on their dashboard gui, this class will be called and open up a new GUI where they can manage their blocked users.

**SellersMessagesGUI**
    When a seller presses the view messages button on their dashboard gui, this class will be called and open up a new GUI where they can view messages.

**User:**
    This class contains the variables and methods that all types of users need. Not only does this class create user objects based on the given variables such as the username and password, but it also implements methods that allow each user to have control over who they choose to block, unblock, or hide from, as well as methods that assist with reading through messages. This is a parent class of Customer.java, Seller.java, and UserManager.java.

**Customer:**
    This class is a child of User.java. However it represents the customer side of User and provides them with customer unique methods. Alongside the user methods, customers can choose to sort and access the statistics of how many messages they have received from stores.

**Seller:**
    Seller is a child class of user.java. In addition to the methods it inherits from the User class, Seller supplies Sellers with methods similar to Customer, which allow them to access the amount of messages they have received and sort them. However, sellers are also provided the methods to create new stores.

**Store:**
    Store is a class that can be used by sellers to create new store objects based on their input. Stores also have the ability to count how many messages they have received, as well as storing and accessing which users have messaged them.

**Message:** 
    The Message class's main functionality is to build a message based on user input and return a string of the message and its details through the toString method. The message class can also be used to check and edit whether a message has been deleted by one of the participants.

stores.csv - each line matches a store object (look at the fields in the store class)

messages.csv - each line matches a message object (look at fields in message class)

login.csv - each line has username, email, password, customer or seller (c or s), list of blocked users, and list of stores owned if user is a seller

csv files are formatted with commas and quotation marks. Click "raw" on the csv file to see. Example (a store object): "storeName","6","Den,Mann,Buyer2,Buyer2"


