import java.io.Serializable;
import java.util.ArrayList;
/**
 * Project 5 - Store class
 * This class creates a store object with three constructors, private fields storeName, messagesReceived,
 * and a list of Buyers that messaged this store.
 *
 * @author Brayden Cho
 */
public class Store implements Serializable {
    private ArrayList<Store> newStores;

    private String storeName;
    private int messagesReceived;
    private String description;
    private int viewCount;

    private ArrayList<Customer> userMessaged = new ArrayList<>();

    // Constructors
    public Store(String storeName, String description) {
        this.storeName = storeName;
        this.viewCount = 0;
        this.description = description;


    }

    public Store(String storeName, int messagesReceived) {
        this.storeName = storeName;
        this.messagesReceived = messagesReceived;
    }

    public Store(String storeName, int messagesReceived, ArrayList<Customer> userMessaged) {
        this.storeName = storeName;
        this.messagesReceived = messagesReceived;
        this.userMessaged = userMessaged;
    }

    // Getters and Setters
    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }
    public void incrementViewCount() {
        viewCount++;
    }

    public int getViewCount() {
        return viewCount;
    }

    public String getDescription() {
        return description;
    }
    public int getMessagesReceived() {
        return messagesReceived;
    }

    public ArrayList<Customer> getUserMessaged() {
        return userMessaged;
    }

    // Message Management
    public void addMessagesReceived() {
        messagesReceived++;
    }

    public void addUserMessaged(Customer customer) {
        userMessaged.add(customer);
    }
    public void createStore(String storeName, String description) {
        Store newStore = new Store(storeName, description);
        newStores.add(newStore);
    }
}

