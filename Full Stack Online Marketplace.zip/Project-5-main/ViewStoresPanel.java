import javax.swing.*;
import java.awt.*;

public class ViewStoresPanel extends JPanel {
    private Seller currentSeller;

    public ViewStoresPanel(Seller seller) {
        this.currentSeller = seller;

        JButton createButton = new JButton("Create Store");
        JButton viewButton = new JButton("View Current Stores");

        createButton.addActionListener(e -> onCreateStoreClicked());
        viewButton.addActionListener(e -> onViewStoresClicked());

        setLayout(new FlowLayout());
        add(createButton);
        add(viewButton);
    }

    private void onCreateStoreClicked() {
        // Placeholder for store creation logic
        String storeName = JOptionPane.showInputDialog(this, "Enter Store Name:");
        String description = JOptionPane.showInputDialog(this, "Enter Store Description:");
        if (storeName != null && description != null) {
            currentSeller.createStore(storeName, description);
            JOptionPane.showMessageDialog(this, "Store Created: " + storeName);
        }
    }

    private void onViewStoresClicked() {
        String storesInfo = currentSeller.viewStoreStatistics();
        JOptionPane.showMessageDialog(this, storesInfo);
    }
}
