import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;
import java.util.stream.Collectors;

public class SellersMessageGUI extends JPanel {
    private Seller currentSeller;
    private List<Message> messages;
    private JList<String> messageDisplayList;
    private DefaultListModel<String> messageListModel;
    private JTextField messageInputField;
    private String receiver;

    public SellersMessageGUI(Seller currentSeller, List<Message> messages) {
        this.currentSeller = currentSeller;
        this.messages = messages;
        this.receiver = receiver;
        initializeComponents();
        loadMessages();
    }

    private void initializeComponents() {
        setLayout(new BorderLayout());
        messageListModel = new DefaultListModel<>();
        messageDisplayList = new JList<>(messageListModel);
        messageDisplayList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        messageInputField = new JTextField(20);

        JButton sendButton = new JButton("Send");
        sendButton.addActionListener(this::onSendMessage);

        add(new JScrollPane(messageDisplayList), BorderLayout.CENTER);
        JPanel inputPanel = new JPanel();
        inputPanel.add(messageInputField);
        inputPanel.add(sendButton);
        add(inputPanel, BorderLayout.SOUTH);
    }

    private void loadMessages() {
        List<String> messageStrings = messages.stream()
                .map(Message::toString)
                .collect(Collectors.toList());
        messageListModel.clear();
        messageStrings.forEach(messageListModel::addElement);
    }
    public void displayMessages(List<Message> messages) {
        for (Message message : messages) {
            if (!currentSeller.isUserBlocked(message.getSender())) {
                // Display the message
                System.out.println(message);
            }
        }
    }

    private void onSendMessage(ActionEvent e) {
        String messageContent = messageInputField.getText();
        if (!messageContent.isEmpty()) {
            currentSeller.sendMessage(receiver, messageContent, messages);
            messageListModel.addElement(new Message(currentSeller.getUsername(), receiver, messageContent).toString());
            messageInputField.setText("");
        }
    }

    // ... other methods ...
}
