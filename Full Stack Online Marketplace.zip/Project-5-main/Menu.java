//Menu.java is the client class of the project. This class contains the GUI that the user will interact with in order to progress through the menus. 
//At the beginning, the user will be able to log in with existing account, create a new account, or exit. 
//Once logged in, the user will be able to write messages, edit them, and delete them. 
//Furthermore, users will also be able to view statistics of those messages, change the password and email of the account, delete their account, and block users from messaging them. 
//Menu.java is used as an interactive shell for the project that will collect information from the client and send it to the server.
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Project 5 - Menu
 * This class creates a client that can connect to a server. Based on the buttons pressed by the user on the GUI, this
 * client class contains the methods to command the server to execute them.
 *
 * @author Jessica He,
 */

public class Menu {
    private Socket socket;
    private BufferedReader reader;
    private PrintWriter writer;
    ObjectOutputStream oos;
    ObjectInputStream ois;

    public void connect() throws IOException {
        socket = new Socket("localhost", 4242);
        reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        writer = new PrintWriter(socket.getOutputStream());
        oos = new ObjectOutputStream(socket.getOutputStream());
        ois = new ObjectInputStream(socket.getInputStream());
    }
    public void disconnect() {
        try {
            socket.close();
            reader.close();
            writer.close();
            oos.close();
            ois.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
    public User authenticate(String username, String password) throws IOException, ClassNotFoundException {
        writer.write("1");
        writer.println();
        writer.flush();
        writer.write(username + "," + password);
        writer.println();
        writer.flush();
        return (User) ois.readObject();
    }

    public boolean register(String username, String email, String password, String userType) throws IOException {
        writer.write("2");
        writer.println();
        writer.flush();
        writer.write(username + "," + email + "," + password + "," + userType);
        writer.println();
        writer.flush();
        return (reader.readLine().equals("true"));
    }

    public ArrayList<User> getBlocked(String username) throws IOException, ClassNotFoundException {
        writer.write("3");
        writer.println();
        writer.flush();
        writer.write(username);
        writer.println();
        writer.flush();
        return (ArrayList<User>) ois.readObject();
    }

    public ArrayList<User> getUnblocked(String username) throws IOException, ClassNotFoundException {
        writer.write("4");
        writer.println();
        writer.flush();
        writer.write(username);
        writer.println();
        writer.flush();
        Object o = ois.readObject();
        return (ArrayList<User>) o;
    }

    public void blockUser(String username, String blockedUser) {
        writer.write("5");
        writer.println();
        writer.flush();
        writer.write(username + "," + blockedUser);
        writer.println();
        writer.flush();
    }

    public ArrayList<Store> getAllStores() throws IOException, ClassNotFoundException {
        writer.write("6");
        writer.println();
        writer.flush();
        return (ArrayList<Store>) ois.readObject();
    }
}
