public class LoginException extends Exception {
    public LoginException(String message) {
        super(message);
    }
}

//for login exceptions in the eventual server class
