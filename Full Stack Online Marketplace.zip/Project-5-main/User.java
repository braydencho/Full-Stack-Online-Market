import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Project 5 - User
 * This class is the underlying structure of each user. It contains the information each
 * user stores such as the user's email, password, email, messages, and blocked users.
 *
 * @author Brayden Cho
 */
public class User implements Serializable {
    // Main fields in the User is email, username, and password
    // It also has additional ArrayList field, which saves the blockedUsers
    private String email;
    public final String username;
    private String password;
    private ArrayList<Message> messages = new ArrayList<>(); // this is an important field that saves
    // all messages that are related to that user
    // we use specific method to parse through messages and assign those values to the messages field
    private ArrayList<User> blockedUsers = new ArrayList<>();
    private ArrayList<String> blockedUsernames = new ArrayList<>();

    // basic constructor, which creates User object using username, email, and password
    // it's not used directly in the Menu.java, it's main purpose is when creating Customer and Seller objects
    public User(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
        initializeMessages();
    }

    public User(String username, String email, String password, ArrayList<String> blockedUsernames) {
        this(username, email, password);
        this.blockedUsernames = blockedUsernames;
    }

    //Initializes the user's messages by reading and parsing messages from the "messages.csv" file.
    private void initializeMessages() {
        try {
            messages = parseMessages();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // This method removes messages from the user's message list if they have been deleted either by the sender or the receiver. It iterates through the messages ArrayList and removes any messages that meet these criteria.
    public void refreshMessages() {
        messages.removeIf(m -> (m.getSender().equals(username) && m.isDeletedBySender()) ||
                (m.getReceiver().equals(username) && m.isDeletedByReceiver()));
    }

    public void updateMessages() {
        initializeMessages();
    }

    //adds user provided in the method to the blockedUsers list
    public boolean blockUser(String username, ArrayList<User> users) {
        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(username) && !blockedUsers.contains(u)) {
                blockedUsers.add(u);
                return true;
            }
        }
        return false;
    }
    // removes specific person from the blockedUsers list
    public boolean unblockUser(String username) {
        return blockedUsers.removeIf(u -> u.getUsername().equalsIgnoreCase(username));
    }

    // Parses and filters messages associated with the user from the "messages.csv" file.
    // Includes messages involving the user (as sender or receiver) that have not been marked as deleted.
   //Returns an ArrayList of Message objects representing the user's messages.
    public ArrayList<Message> parseMessages() throws IOException {
        ArrayList<Message> wholeFile = readWholeFile();
        ArrayList<Message> temp = new ArrayList<>();
        for (Message line : wholeFile) {
            if ((line.getSender().equals(username) && !line.isDeletedBySender()) ||
                    (line.getReceiver().equals(username) && !line.isDeletedByReceiver())) {
                temp.add(line);
            }
        }
        return temp;
    }
    // This method reads the entire "messages.csv" file and parses its contents into a list of Message objects. It returns an ArrayList of Message objects.
    public ArrayList<Message> readWholeFile() throws IOException {
        ArrayList<Message> fileContent = new ArrayList<>();
        try (BufferedReader bfr = new BufferedReader(new FileReader("messages.csv"))) {
            String st;
            while ((st = bfr.readLine()) != null) {
                ArrayList<String> temp = customSplitSpecific(st);
                fileContent.add(new Message(Integer.parseInt(temp.get(0).substring(1, temp.get(0).length() - 1))
                        , temp.get(1), temp.get(2), temp.get(3), temp.get(4), Boolean.parseBoolean(temp.get(5))
                        , Boolean.parseBoolean(temp.get(6))));
            }
        }
        return fileContent;
    }

    /* this is very useful method that is used to read singular lines in the files
    A utility method that splits a CSV line into an ArrayList of strings.
   Handles cases where commas may appear within double-quotes.
   For example we receive an line - "abc","34234","I like apples, bananas, watermelon"
   As an output it will give us an ArrayList abc(for example) where
   abc.get(0)     ->   abc
   abc.get(1)     ->   34234
   abc.get(2)     ->   I like apples, bananas, watermelon
   We couldn't use regular split() function, so we created this one to help us solve the problem
   */
   ArrayList<String> customSplitSpecific(String s) {
        ArrayList<String> words = new ArrayList<>();
        boolean notInsideComma = true;
        int start = 0;
        for (int i = 0; i < s.length() - 1; i++) {
            if (s.charAt(i) == ',' && notInsideComma) {
                words.add(s.substring(start, i));
                start = i + 1;
            } else if (s.charAt(i) == '"') {
                notInsideComma = !notInsideComma;
            }
        }
        words.add(s.substring(start));
        return words;
    }

    // Getters and setters
    public String getUsername() { return username; }
    public void setEmail(String email) { this.email = email; }
    public ArrayList<Message> getMessages() { return messages; }
    public void setMessages(ArrayList<Message> messages) { this.messages = messages; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getEmail() { return email; }
    public ArrayList<String> getBlockedUsernames() { return blockedUsernames; }
    public ArrayList<User> getBlockedUsers() { return blockedUsers; }
    public void setBlockedUsers(ArrayList<User> blockedUsers) { this.blockedUsers = blockedUsers; }
    public void setBlockedUsernames(ArrayList<String> blockedUsernames) { this.blockedUsernames = blockedUsernames; }

    //sets all main values to null to delete the user
    public void removeUser() {
        email = null;
        password = null;
        blockedUsers = null;
        messages = null;
    }
}
