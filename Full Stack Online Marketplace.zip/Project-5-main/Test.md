# Testing

## Test 1: User Log In

Steps:

    1. User launches application.
    2. User selects log in button.
    3. Users selects the username textbox.
    4. User enters username via the keyboard.
    5. User selects the password textbox.
    6. User enters the password via the keyboard.
    7. User selects the enter button.

Expected result: Application verifies the username and password and loads the user's homepage alongside a JOptionPane
welcome message.

Test Status: Passed.

## Test 2: User Log In With Input Error

Steps:

    1. User launches application.
    2. User selects log in button.
    3. User leaves the username textbox blank.
    4. User selects the password textbox.
    5. User enters the password via the keyboard.
    6. User selects the enter button.

Expected result: JOptionPane error pop up displays to the user that they must fill all fields.

Test Status: Passed.

## Test 3: User Log In With Incorrect Password

Steps:

    1. User launches application.
    2. User selects log in button.
    3. User selects the username button.
    4. User enters the username via the keyboard.
    5. User selects the password textbox.
    6. User enters the incorrect password via the keyboard.
    7. User selects the enter button.

Expected result: Application will not verify the username and password. A red log in error will be displayed under the
username and password text boxes.

Test Status: Passed.

## Test 4: User Sign Up

Steps:

    1. User launches application.
    2. User selects sign up button.
    3. User selects the username textbox.
    4. User enters their desired username via the keyboard.
    5. User selects the password textbox.
    6. User enters their desired password via the keyboard.
    7. User selects the email textbox.
    8. User enters their email via the keyboard.
    9. User selects either the customer or seller checkbox.
    10. User selects the enter button.

Expected result: Application will verify that the username is unique and ask them to login again, which will load their given dashboard with a welcome message.

Test Status: Passed.

## Test 5: User Sign Up With Already Taken Username

Steps:

    1. User launches application.
    2. User selects sign up button.
    3. User selects the username textbox.
    4. User enters their desired username, but non unique via the keyboard.
    5. User selects the password textbox.
    6. User enters their desired password via the keyboard.
    7. User selects the email textbox.
    8. User enters their email via the keyboard.
    9. User selects either the customer or seller checkbox.
    10. User selects the enter button.

Expected result: Application will verify that the username is not unique and prompt the user to try again with a
JOptionPane error message.

Test Status: Passed.

## Test 6: User Sign Up With Input Error

Steps:

    1. User launches application.
    2. User selects sign up button.
    3. User selects the username textbox.
    4. User enters their desired username, but non unique via the keyboard.
    5. User selects the password textbox.
    6. User enters their desired password via the keyboard.
    7. User selects the email textbox.
    8. User enters their email via the keyboard.
    9. User  does not select either the customer or seller checkbox.
    10. User selects the enter button.

Expected result: JOptionPane error pop up displays to the user that they must fill all fields.

Test Status: Passed.

## Test 7: Multi Client Use

Steps:

    1. User 1 launches application.
    2. User 2 launches application.
    3. User 1 selects sign up button.
    4. User 2 selects sign up button.
    5. User 1 selects the username textbox.
    6. User 2 selects the username textbox.
    7. User 1 enters their desired username via the keyboard.
    8. User 2 enters their desired username via the keyboard.
    9. User 1 selects the password textbox.
    10. User 2 selects the password textbox.
    11. User 1 enters their desired password via the keyboard.
    12. User 2 enters their desired password via the keyboard.
    13. User 1 selects the email textbox.
    14. User 2 selects the email textbox.
    15. User 1 enters their email via the keyboard.
    16. User 2 enters their email via the keyboard.
    17. User 1 does not select either the customer or seller checkbox.
    18. User 2 does not select either the customer or seller checkbox.
    19. User 1 selects the enter button.
    20. User 2 selects the enter button.

Expected result: Both users can create accounts in separately running windows.

Test Status: Passed.

## Test 8: Customer Blocking

Steps:

    1. Logged in customer navigates to their profile button.
    2. User selects manage blocked users button.
    3. User selects user they would like to block in the dropdown.
    4. User presses the add button.

Expected result: If the selected user has successfully been blocked and added to the current users blocked list, their name should appear in the JScrollPane to the left of the dropdown.

Test Status: Passed.
