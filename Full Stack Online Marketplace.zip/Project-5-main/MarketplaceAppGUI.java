import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/**
 * Project 5 - MarketplaceAppGUI
 * This class creates a GUI of the Marketplace dashboard, in which the customer can communicate their desired
 * commands to the server via buttons and text fields.
 */

public class MarketplaceAppGUI extends JComponent implements Runnable {
    private JFrame startFrame;
    private static User currentUser;
    Menu client = new Menu();
    JButton loginButton;
    JButton signUpButton;
    JButton loginEnterButton;
    JButton suEnterButton;
    JButton backButton;
    JTextField userText;
    JTextField passText;
    JTextField emailText;
    JCheckBox seller = new JCheckBox("Seller");
    JCheckBox customer = new JCheckBox("Customer");
    private boolean loginFailed = false;
    ActionListener actionListener = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == loginButton) {
                startFrame.setVisible(false);
                refreshPage();
                loginPage();
            }
            if (e.getSource() == signUpButton) {
                startFrame.setVisible(false);
                refreshPage();
                signUpPage();
            }
            if (e.getSource() == loginEnterButton) {
                String username = "";
                String password = "";
                username = userText.getText();
                password = passText.getText();
                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please Complete all fields", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        currentUser = client.authenticate(username, password);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    } catch (ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                    if (currentUser == null) {
                        loginFailed = true;
                        refreshPage();
                        loginPage();
                        loginFailed = false;
                    } else {
                        if (currentUser instanceof Customer) {
                            CustomerDashboardGUI dashboardGUI = new CustomerDashboardGUI(client, (Customer) currentUser);
                            dashboardGUI.run();
                            startFrame.setVisible(true);
                            startFrame.dispose();
                            JOptionPane.showMessageDialog(null, "Welcome " + currentUser.getUsername()
                                    , null, JOptionPane.INFORMATION_MESSAGE);
                            return;
                            //CustomerDashboardGUI.
                        } else if (currentUser instanceof Seller) {
                            SellersDashboardGUI dashboardGUI = new SellersDashboardGUI();
                            dashboardGUI.setVisible(true);
                            JOptionPane.showMessageDialog(null, "Welcome " + currentUser.getUsername()
                                    , null, JOptionPane.INFORMATION_MESSAGE);
                        }

                    }
                }
            }
            if (e.getSource() == suEnterButton) {
                String username = "";
                String password = "";
                String email = "";
                String accountType = "";
                username = userText.getText();
                password = passText.getText();
                email = emailText.getText();
                if (seller.isSelected()) {
                    accountType = "seller";
                } else if (customer.isSelected()) {
                    accountType = "customer";
                }
                boolean isRegistered = false;
                if (username.isEmpty() || password.isEmpty() || email.isEmpty() || accountType.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please Complete all fields", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        isRegistered = client.register(username, email, password, accountType);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                    if (isRegistered) {
                        JOptionPane.showMessageDialog(null, "Registration Successful", null,
                                JOptionPane.INFORMATION_MESSAGE);
                        startFrame.setVisible(false);
                        refreshPage();
                        startPage();
                    } else {
                        JOptionPane.showMessageDialog(null,
                                "Registration failed. Username might be taken, or invalid user type.", null,
                                JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
            if (e.getSource() == backButton) {
                startFrame.setVisible(false);
                refreshPage();
                startPage();
            }
        }
    };

    @Override
    public void run() {
        try {
            client.connect();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        boolean starterFrame = true;
        while (starterFrame) {
            startPage();
            starterFrame = false;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new MarketplaceAppGUI());
    }

    public void  startPage() {
        //loads the welcome page providing the option to login or sign up
        startFrame = new JFrame("Marketplace");
        Container container = startFrame.getContentPane();
        JPanel startPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        JLabel welcome = new JLabel("Welcome to The Marketplace Application!");

        loginButton = new JButton("Login");
        loginButton.setPreferredSize(new Dimension(80, 25));
        loginButton.addActionListener(actionListener);
        signUpButton = new JButton("Sign Up");
        signUpButton.setPreferredSize(new Dimension(80, 25));
        signUpButton.addActionListener(actionListener);

        gbc.gridx = 1;
        gbc.gridy = 1;
        startPanel.add(welcome, gbc);

        gbc.insets = new Insets(65,0,0,0);
        gbc.gridx = 1;
        gbc.gridy = 2;
        startPanel.add(loginButton, gbc);
        gbc.insets = new Insets(15,0,0,0);
        gbc.gridx = 1;
        gbc.gridy = 3;
        startPanel.add(signUpButton, gbc);

        container.add(startPanel, BorderLayout.CENTER);

        startFrame.setSize(400, 300);
        startFrame.setLocationRelativeTo(null);
        startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        startFrame.setVisible(true);
    }

    public void loginPage() {
        // loads the page that allows the user to enter username and password
        Container container = startFrame.getContentPane();
        JPanel loginPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        JLabel info = new JLabel("Enter Your Username And Password Below ");
        JLabel username = new JLabel("Username: ");
        JLabel password = new JLabel("Password: ");
        userText = new JTextField("", 10);
        passText = new JTextField("", 10);
        loginEnterButton = new JButton("Enter");
        loginEnterButton.addActionListener(actionListener);
        backButton = new JButton("Back");
        backButton.addActionListener(actionListener);
        JLabel failure = new JLabel("Login failed, please try again.");

        container.add(loginPanel);
        gbc.insets = new Insets(0,0,25,0);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        loginPanel.add(info, gbc);
        gbc.gridwidth = 1;
        gbc.insets = new Insets(0,35,0,-25);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_END;
        loginPanel.add(username, gbc);
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_START;
        loginPanel.add(userText, gbc);
        gbc.insets = new Insets(10,35,0,-25);
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_END;
        loginPanel.add(password, gbc);
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_START;
        loginPanel.add(passText, gbc);
        gbc.insets = new Insets(20,20,0,0);
        gbc.gridwidth = 2;
        gbc.gridx = 2;
        gbc.gridy = 5;
        loginPanel.add(loginEnterButton, gbc);
        gbc.insets = new Insets(0,20,-100,0);
        backButton.setContentAreaFilled(false);
        backButton.setOpaque(false);
        backButton.setBorderPainted(false);
        gbc.gridx = 2;
        gbc.gridy = 6;
        loginPanel.add(backButton, gbc);

        if (loginFailed) {
            failure.setForeground(Color.RED);
            gbc.insets = new Insets(10,-25,0,0);
            gbc.gridwidth = 2;
            gbc.gridx = 2;
            gbc.gridy = 4;
            loginPanel.add(failure, gbc);
        }

        startFrame.setSize(600, 400);
        startFrame.setLocationRelativeTo(null);
        startFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        startFrame.setVisible(true);
    }

    public void signUpPage() {
        // loads the sign up page where a user can enter their chosen username, password, and email
        Container container = startFrame.getContentPane();
        JPanel loginPanel = new JPanel(new GridBagLayout());
        container.add(loginPanel);
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel info = new JLabel("Enter Your Username And Password Below ");
        JLabel username = new JLabel("Username: ");
        JLabel password = new JLabel("Password: ");
        userText = new JTextField("", 10);
        passText = new JTextField("", 10);
        emailText = new JTextField("", 10);
        suEnterButton = new JButton("Enter");
        suEnterButton.addActionListener(actionListener);
        backButton = new JButton("Back");
        backButton.addActionListener(actionListener);
        JLabel emailButton = new JLabel("Email: ");
        seller = new JCheckBox("Seller");
        customer = new JCheckBox("Customer");

        gbc.insets = new Insets(0,0,25,0);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        loginPanel.add(info, gbc);
        gbc.gridwidth = 1;
        gbc.insets = new Insets(0,35,0,-25);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_END;
        loginPanel.add(username, gbc);
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_START;
        loginPanel.add(userText, gbc);
        gbc.insets = new Insets(10,35,0,-25);
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_END;
        loginPanel.add(password, gbc);
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_START;
        loginPanel.add(passText, gbc);
        gbc.insets = new Insets(10,35,0,-25);
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.LINE_END;
        loginPanel.add(emailButton, gbc);
        gbc.gridx = 2;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.LINE_START;
        loginPanel.add(emailText, gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        loginPanel.add(seller, gbc);
        gbc.gridx = 2;
        gbc.gridy = 5;
        loginPanel.add(customer, gbc);
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(seller);
        buttonGroup.add(customer);

        gbc.insets = new Insets(25,20,0,0);
        gbc.gridwidth = 2;
        gbc.gridx = 2;
        gbc.gridy = 6;
        loginPanel.add(suEnterButton, gbc);
        gbc.insets = new Insets(0,20,-100,0);
        backButton.setContentAreaFilled(false);
        backButton.setOpaque(false);
        backButton.setBorderPainted(false);
        gbc.gridx = 2;
        gbc.gridy = 6;
        loginPanel.add(backButton, gbc);

        startFrame.setSize(600, 400);
        startFrame.setLocationRelativeTo(null);
        startFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        startFrame.setVisible(true);
    }

    public void refreshPage() {
        startFrame.getContentPane().removeAll();
        startFrame.repaint();
    }

}