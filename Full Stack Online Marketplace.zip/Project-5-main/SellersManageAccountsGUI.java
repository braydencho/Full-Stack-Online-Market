import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;


public class SellersManageAccountsGUI extends JPanel {
    private Seller currentSeller;
    private JButton viewStoresButton, viewStatsButton, blockUserButton;
    private List<Message> messages;

    public SellersManageAccountsGUI(Seller currentSeller) {
        this.currentSeller = currentSeller;
        this.messages = new ArrayList<>();  // Initialize with empty list or fetch existing messages

        setLayout(new BorderLayout());

        // Initialize Buttons
        viewStoresButton = new JButton("View Stores");

        viewStatsButton = new JButton("View Statistics");
        blockUserButton = new JButton("Block User");

        // Set up action listeners
        viewStoresButton.addActionListener(this::viewStoresAction);
        viewStatsButton.addActionListener(this::viewStatsAction);
        blockUserButton.addActionListener(this::blockUserAction);

        // Add buttons to the panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(viewStoresButton);
        buttonPanel.add(viewStatsButton);
        buttonPanel.add(blockUserButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void viewStoresAction(ActionEvent e) {
        JFrame frame = new JFrame("Store Management");
        frame.setContentPane(new ViewStoresPanel(currentSeller));
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);    }

    private void onViewStoresClicked() {
        JFrame frame = new JFrame("Manage Stores");
        ViewStoresPanel viewStoresPanel = new ViewStoresPanel(currentSeller); // Pass currentSeller
        frame.setContentPane(viewStoresPanel);
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void viewStatsAction(ActionEvent e) {
        String stats = currentSeller.viewStoreStatistics();
        JOptionPane.showMessageDialog(this, stats);
    }
    private void createStoresAction(ActionEvent e) {
        JTextField storeNameField = new JTextField(20);
        JTextArea descriptionArea = new JTextArea(5, 20);

        JPanel panel = new JPanel();
        panel.add(new JLabel("Store Name:"));
        panel.add(storeNameField);
        panel.add(Box.createVerticalStrut(15)); // Spacer
        panel.add(new JLabel("Description:"));
        panel.add(new JScrollPane(descriptionArea));

        int result = JOptionPane.showConfirmDialog(null, panel,
                "Create New Store", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String storeName = storeNameField.getText();
            String description = descriptionArea.getText();
            currentSeller.createStore(storeName,
                    description);
            JOptionPane.showMessageDialog(null, "Store Created Successfully!");
        }
    }


    private void blockUserAction(ActionEvent e) {
        String usernameToBlock = JOptionPane.showInputDialog(this, "Enter Username to Block:");
        if (usernameToBlock != null && !usernameToBlock.trim().isEmpty()) {
            currentSeller.blockUser(usernameToBlock.trim());
            JOptionPane.showMessageDialog(this, "User " + usernameToBlock + " has been blocked.");
        }
    }

}

