import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.List;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;


/**
 * Project 5 - Seller
 * This class extends the user class giving it the permissions that come with being a seller.
 * Includes a private ArrayList field of sellers.
 *
 * @author Brayden Cho
 */

public class Seller extends User {

    /*
    compared to the parent class User, Seller class has additional values such as stores, in order to keep track of the stores which our Seller owns
    */

    private ArrayList<Store> stores;
    private JFrame stats;
    private Set<String> blockedUsers;



    public Seller(String username, String email, String password) {
        super(username, email, password);
        this.blockedUsers = new HashSet<>();
        this.stores = new ArrayList<>();

    }

    public Seller (String username, String email, String password, ArrayList<String> blockedUsernames) {
        super(username, email, password, blockedUsernames);
    }


    public void blockUser(String username) {
        blockedUsers.add(username);
    }
    public boolean isUserBlocked(String username) {
        return blockedUsers.contains(username);
    }

    public String viewStoreStatistics() {
        StringBuilder statistics = new StringBuilder();
        for (Store store : stores) { // Ensure 'stores' is a list of Store objects
            statistics.append("Store: ")
                    .append(store.getStoreName()) // Correct method call on a Store object
                    .append(", Views: ")
                    .append(store.getViewCount()) // Correct method call on a Store object
                    .append("\n");
        }
        return statistics.toString();
    }
    public void createStore(String storeName, String description) {
        Store store = new Store(storeName, description);
        stores.add(store);
    }



    public ArrayList<Store> getStores() {
        return stores;
    }

   public String viewStatistics(boolean alphabetical) throws IOException {
        FileReader fr = new FileReader("messages.csv");
        BufferedReader br = new BufferedReader(fr);
        ArrayList<String> messages = new ArrayList<>();
        ArrayList<String> senders = new ArrayList<>();
        ArrayList<Integer> messageCount = new ArrayList<>();
        ArrayList<String> words = new ArrayList<>();
        ArrayList<String> uniqueWords = new ArrayList<>();
        ArrayList<Integer> wordUsage = new ArrayList<>();
        int secondCommaIndex;
        int thirdCommaIndex;
        String sender;
        String receiver;
        String line;

        line = br.readLine();
        while (line != null) {
            secondCommaIndex = line.indexOf(',', line.indexOf(',') + 1);
            thirdCommaIndex = line.indexOf(',', secondCommaIndex + 1);
            receiver = line.substring(secondCommaIndex + 1, thirdCommaIndex);
            if (receiver.equals(getUsername())) {
                messages.add(line);
            }
            sender = line.substring(0, secondCommaIndex);
            if (!senders.contains(sender)) {
                senders.add(sender);
            }
            line = br.readLine();
        }

        for (int i = 0; i < senders.size(); i++) {
            int messageCounter = 0;
            for (int j = 0; j < messages.size(); j++) {
                line = messages.get(j);
                sender = line.substring(0, line.indexOf(','));
                if (senders.get(i).equals(sender)) {
                    messageCounter++;
                }
            }
            messageCount.add(messageCounter);
        }

        for (int i = 0; i < messages.size(); i++) {
            line = messages.get(i);
            line = line.replaceAll("\\p{Punct}", "");
            String[] wordArray = line.split(" ");
            for (String word : wordArray) {
                words.add(word);
            }
        }

        for (String word : words) {
            if (!uniqueWords.contains(word)) {
                uniqueWords.add(word);
            }
        }

        for (String uniqueWord : uniqueWords) {
            int usageCount = 0;
            for (String word : words) {
                if (uniqueWord.equals(word)) {
                    usageCount++;
                }
            }
            wordUsage.add(usageCount);
        }

        int wordOneUses = 0, wordTwoUses = 0, wordThreeUses = 0;
        int wordOneIndex = 0, wordTwoIndex = 0, wordThreeIndex = 0;
        for (int i = 0; i < wordUsage.size(); i++) {
            if (wordUsage.get(i) > wordOneUses) {
                wordThreeUses = wordTwoUses;
                wordTwoUses = wordOneUses;
                wordOneUses = wordUsage.get(i);
                wordThreeIndex = wordTwoIndex;
                wordTwoIndex = wordOneIndex;
                wordOneIndex = i;
            } else if (wordUsage.get(i) > wordTwoUses) {
                wordThreeUses = wordTwoUses;
                wordTwoUses = wordUsage.get(i);
                wordThreeIndex = wordTwoIndex;
                wordTwoIndex = i;
            } else if (wordUsage.get(i) > wordThreeUses) {
                wordThreeUses = wordUsage.get(i);
                wordThreeIndex = i;
            }
        }

        StringBuilder statistics = new StringBuilder();
        HashMap<String, Integer> hashMap = new HashMap<>();
        for (int i = 0; i < senders.size(); i++) {
            hashMap.put(senders.get(i), messageCount.get(i));
        }
        Collections.sort(senders);
        if (alphabetical) {
            for (int i = 0; i < senders.size(); i++) {
                statistics.append("Customers: ")
                          .append(senders.get(i))
                          .append(" - Messages sent: ")
                          .append(hashMap.get(senders.get(i)))
                          .append("\n");
            }
        } else {
            for (int i = senders.size() - 1; i >= 0; i--) {
                statistics.append("Customers: ")
                          .append(senders.get(i))
                          .append(" - Messages sent: ")
                          .append(hashMap.get(senders.get(i)))
                          .append("\n");
            }
        }

        String wordOne = uniqueWords.get(wordOneIndex);
        String wordTwo = uniqueWords.get(wordTwoIndex);
        String wordThree = uniqueWords.get(wordThreeIndex);
        statistics.append("Most frequently used words: ")
                  .append(wordOne)
                  .append(", ")
                  .append(wordTwo)
                  .append(", and ")
                  .append(wordThree);

       stats = new JFrame();

        JOptionPane.showMessageDialog(stats, statistics.toString());

        return statistics.toString();
    }
    @Override
    public String toString() {
        String blockedList = "";
        if (getBlockedUsers().size() > 0) {
            for (User user : getBlockedUsers()) {
                blockedList += user.getUsername() + ",";
            }
            blockedList = blockedList.substring(0, blockedList.length() - 1);
        }
        String storesList = "";
        if (getStores().size() > 0) {
            for (Store store : getStores()) {
                storesList += store + ",";
            }
            storesList = storesList.substring(0, storesList.length() - 1);
        }

        String ans = String.format("\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"", getUsername(), getEmail(),
                getPassword(), "s", blockedList, storesList);
        return ans;
    }
    public void sendMessage(String receiver, String messageContent, List<Message> messageList) {
        Message newMessage = new Message(this.username, receiver, messageContent);
        messageList.add(newMessage);
    }

}
