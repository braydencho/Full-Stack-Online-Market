import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
/**
 * Project 5 - Server
 * This class creates a server that users can connect to. When the clients connect, this class will create a new thread
 * for that user.
 *
 * @author Jessica He, Brayden Cho
 */
public class Server {
    private final ServerSocket server;
    public Server(ServerSocket server) {
        this.server = server;
    }

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(4242);
        Server server = new Server(serverSocket);
        server.start();
    }

    public void start() {
        try {
            while (!server.isClosed()) {
                Socket client = server.accept();
                UserThread user = new UserThread(client);
                Thread userThread = new Thread(user);
                userThread.start();
            }
            close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void close() {
        try {
            if (server != null) {
                server.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}